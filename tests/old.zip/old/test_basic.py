"""
Basic test to verify pytest is working.
"""


def test_pytest_works():
    """Simple test to verify pytest is working."""
    assert True, "pytest is working"
